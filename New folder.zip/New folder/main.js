var Typed = new Typed(".text1", {
strings: [ " Front End Developer","Application developer" ], 
typeSpeed:100,
backSpeed:100,
backDelay:1000,
loop:true
});